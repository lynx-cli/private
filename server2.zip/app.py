import mysql.connector
import json
import os
from flask import Flask, request, render_template, send_file

app = Flask(__name__)

# Define a route for the root URL
@app.route('/sys',methods=['POST'])
def index():
    serial = request.args.get('serial', '')
    content = ""
    with open('sys/'+serial, 'r') as file:
        content = file.read()
    return content

@app.route('/res')
def icon():
    serial = request.args.get('serial', '')
    file_path = os.path.join('res', serial)
    return send_file(file_path, as_attachment=True)

@app.route('/<path:path>')
def static_file(path):
    return app.send_static_file(path)

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000,debug=False)
